package servlet.model;

public class Book {
	private String isbn;
	private String title;
	private String catalogue;
	private String nation;
	private String publishDate;//publishDate
	private String publisher;
	private String author;
	private int price;
	private String currency;
	private String description;
	private static final String defaultNation = "어디사니";
	private static final String defaultDescription = "설명 좀 써주라";
	public Book() {}

	public Book(String isbn, String title, String catalogue, String nation, String publishDate, String publisher,
			String author, int price, String currency, String description) {
		this.isbn = isbn;
		this.title = title;
		this.catalogue = catalogue;
		if(nation.equals("") || nation == null) this.nation = defaultNation;
		else this.nation = nation;
		this.publishDate = publishDate;
		this.publisher = publisher;
		this.author = author;
		this.price = price;
		this.currency = currency;
		if(description.equals("") || description == null) this.description = defaultDescription;
		else this.description = description;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCatalogue() {
		return catalogue;
	}

	public void setCatalogue(String catalogue) {
		this.catalogue = catalogue;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public String getPublishDate() {
		return publishDate;
	}

	public void publishDate(String publish_date) {
		this.publishDate = publish_date;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", catalogue=" + catalogue + ", nation=" + nation
				+ ", publishDate=" + publishDate + ", publisher=" + publisher + ", author=" + author + ", price="
				+ price + ", currency=" + currency + ", description=" + description + "]";
	}

}
